package queries;

import java.util.List;

import org.neo4j.driver.Record;
import org.neo4j.driver.Result;
import org.neo4j.driver.types.Node;
import org.neo4j.driver.types.Relationship;

import neo4j.MainWindow;

public class Query6 implements MyQuery {
	private MainWindow mw;

	public Query6(MainWindow mw) {
		this.mw = mw;
	}

	@Override
	public String getQuery() {
		return "MATCH path = (n)-[r1:RAILWAY]-(l)-[r2*1..3]-(t:Valley) "
				+ "WHERE l.name='Langreo' AND n.name =~ \"[aeiouAEIOU].*\" "
				+ "RETURN n, nodes(path), relationships(path) " + "LIMIT 25";
	}

	@Override
	public void printResult(Result result) {
		String str = "";
		while (result.hasNext()) {

			Record r = result.next();

			Node n = null;
			n = r.get("n", n);
			String name = n.get("name").toString().replace("\"", "");
			str += "-> (" + name + ")-";

			List<Object> nodes = null;
			nodes = r.get("nodes(path)", nodes);

			List<Object> relationships = null;
			relationships = r.get("relationships(path)", relationships);

			for (int j = 1; j < nodes.size(); j++) {
				Relationship rel = (Relationship) relationships.get(j - 1);
				str += "[" + rel.type() + "]-";
				Node node = (Node) nodes.get(j);
				str += "(" + node.get("name").toString().replace("\"", "") + ")-";
				
				if (j == nodes.size() - 1) { // is the last one
					str = str.substring(0, str.length() - 1) + "\n";
				}

			}
		}

		mw.setResult(str);

	}

	@Override
	public String getDescripcion() {
		return "From every possible path between any node that is adjacent to Langreo by train "
				+ "and a valley return the departure node, the nodes in the path and the relationships traversed. "
				+ "The first node must start with a vowel";
	}
}
