package queries;

import java.util.List;

import org.neo4j.driver.Record;
import org.neo4j.driver.Result;
import org.neo4j.driver.types.Node;
import org.neo4j.driver.types.Relationship;

import neo4j.MainWindow;

public class Query5 implements MyQuery {

	private MainWindow mw;

	public Query5(MainWindow mw) {
		this.mw = mw;
	}

	@Override
	public String getQuery() {
		return "MATCH shortestPath((a)-[c:BUSLINE|:RAILWAY|:BOAT*]-(b)) "
				+ "WHERE a.name='Pola de Lena' and b.name='Gij�n' "
				+ "RETURN reduce (var=0,v1 in c | var+v1.avg_ride_time) as Total_Time, reduce(var = 0, v1 in c | var + v1.price) as Total_Price, c as Relationships,extract(x in c|startnode(x)) as InitialNodes,extract(x in c|endnode(x)) as EndNodes "
				+ "LIMIT 25";
	}

	@Override
	public void printResult(Result result) {
		String str = "";
		while (result.hasNext()) {

			Record r = result.next();
			List<Object> startNodes = null;
			startNodes = r.get("InitialNodes", startNodes);
			List<Object> endNodes = null;
			endNodes = r.get("EndNodes", endNodes);

			List<Object> relationships = null;
			relationships = r.get("Relationships", relationships);

			for (int j = 0; j < startNodes.size(); j++) {
				Node startNode = (Node) startNodes.get(j);
				str += "(" + startNode.get("name").toString().replace("\"", "") + ")-";

				Relationship rel = (Relationship) relationships.get(j);
				str += "[" + rel.type()+" price: "+rel.get("price")+" � avg_ride_time: "+rel.get("avg_ride_time") + " min]-";

				if (j == startNodes.size() - 1) { // is the last one
					Node endNode = (Node) endNodes.get(endNodes.size() - 1);
					str += "(" + endNode.get("name").toString().replace("\"", "") + ")\n";
				}

			}
			
			str+="\nTotal time: "+r.get("Total_Time")+" min \n";
			str+="Total price: "+r.get("Total_Price")+" � \n";
			
		}
		
		mw.setResult(str);
	}

	@Override
	public String getDescripcion() {
		return "Return the shortest path (including each of the nodes) in between Gij�n and Pola de Lena, along with the total trip time and the amount paid";
	}

}
